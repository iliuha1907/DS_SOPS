﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DS_Lab1.Models
{
	public class Player
	{
		public string PlayerId { get; set; }

		public int Jersey { get; set; }

		public string Fname { get; set; }

		public string Sname { get; set; }

		public string Position { get; set; }

		public DateTime Birthday { get; set; }

		public int Weight { get; set; }
			  
		public int Height { get; set; }

		public string Birthcity { get; set; }

		public string Birthstate { get; set; }
	}
}