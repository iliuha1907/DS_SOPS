﻿using System.Data.Entity.ModelConfiguration;

namespace DS_Lab1.Models
{
	internal class PlayerMap : EntityTypeConfiguration<Player>
	{
		public PlayerMap()
		{
			ToTable("roster");

			Property(p => p.PlayerId).IsRequired();
			Property(p => p.Jersey).IsOptional();
			Property(p => p.Fname).IsOptional();
			Property(p => p.Sname).IsOptional();
			Property(p => p.Position).IsOptional();
			Property(p => p.Birthday).IsOptional();
			Property(p => p.Weight).IsOptional();
			Property(p => p.Height).IsOptional();
			Property(p => p.Birthcity).IsOptional();
			Property(p => p.Birthstate).IsOptional();
		}
	}
}