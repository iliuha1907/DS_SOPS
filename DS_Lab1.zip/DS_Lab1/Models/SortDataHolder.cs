﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DS_Lab1.Models
{
	public class SortDataHolder
	{
		public string Position { get; set; } = "";

		public DateTime FirstBirth { get; set; }

		public DateTime LastBirth { get; set; }
	}
}