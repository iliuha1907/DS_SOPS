﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace DS_Lab1.Models
{
	public class PlayerContext : DbContext
	{
		public DbSet<Player> Players { get; set; }

		public PlayerContext() : base(GetConnection(), false)
		{
		}

		public static DbConnection GetConnection()
		{
			var connection = ConfigurationManager.ConnectionStrings["SQLiteConnection"];
			var factory = DbProviderFactories.GetFactory(connection.ProviderName);
			var dbCon = factory.CreateConnection();
			dbCon.ConnectionString = connection.ConnectionString;
			return dbCon;
		}

		protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
			modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
			modelBuilder.Configurations.Add(new PlayerMap());
			base.OnModelCreating(modelBuilder);
		}
	}
}