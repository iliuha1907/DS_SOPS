﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DS_Lab1.Models;

namespace DS_Lab1.Controllers
{
	public class HomeController : Controller
	{
		PlayerContext db = new PlayerContext();
		static SortDataHolder mainSortDataHolder;

		public ActionResult Index()
		{
			IEnumerable<Player> players = db.Players;
			ViewBag.Players = players;
			return View();
		}

		[HttpPost]
		[HandleError(ExceptionType = typeof(System.FormatException), View = "Failure")]
		public ActionResult Show(DateTime firstDate, DateTime lastDate, string position)
		{
			IEnumerable<Player> players = db.Players;
			SortDataHolder sortDataHolder = new SortDataHolder();
			players = players.Where(player => player.Birthday.CompareTo(firstDate) >= 0);
			sortDataHolder.FirstBirth = firstDate;
			players = players.Where(player => player.Birthday.CompareTo(lastDate) <= 0);
			sortDataHolder.LastBirth = lastDate;
			if (position != "")
			{
				players = players.Where(player => player.Position.Equals(position));
				sortDataHolder.Position = position;
			}
			ViewBag.Players = players;
			mainSortDataHolder = sortDataHolder;
			return View();
		}

		[HttpGet]
		public ActionResult Update1(string id)
		{
			Player player = db.Players.Where(p => p.PlayerId.Equals(id)).FirstOrDefault();
			ViewBag.Player = player;
			string date = player.Birthday.Year + "-" + player.Birthday.Month + "-" + player.Birthday.Day;
			ViewBag.BDay = date;
			return View("Update");
		}
		[HandleError(ExceptionType = typeof(System.FormatException), View = "Failure")]
		[HttpPost]
		public ActionResult Update(string playerId, DateTime birthday, string birthcity, string birthstate)
		{
			Player playerOld = db.Players.Where(p => p.PlayerId.Equals(playerId)).FirstOrDefault();
			if (birthday.CompareTo(mainSortDataHolder.FirstBirth) < 0)
			{
				throw new FormatException();
			}
			if (birthday.CompareTo(mainSortDataHolder.LastBirth) > 0)
			{
				throw new FormatException();
			}
			playerOld.Birthday = birthday;

			if (birthcity != "")
			{
				playerOld.Birthcity = birthcity;
			}
			if (birthstate != "")
			{
				playerOld.Birthstate = birthstate;
			}
			db.SaveChanges();
			return View("Index");
		}

		[HttpGet]
		public ActionResult BackHome()
		{
			return View("Index");
		}
	}
}